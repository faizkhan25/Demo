package com.example.demo;

import java.sql.*;
import java.util.*;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class StudentDAO {

    @Autowired
    DataSource datasource;

    public void save(Student student) throws SQLException {
        String query = "INSERT INTO student(name, email, eventname) VALUES(?,?,?)";
        try (Connection con = datasource.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, student.getName());
            ps.setString(2, student.getEmail());
            ps.setString(3, student.getEventname());
            ps.executeUpdate();
        }
    }

    public List<Student> getStu() throws SQLException {
        List<Student> list = new ArrayList<>();
        String query = "SELECT * FROM student";
        Connection con = datasource.getConnection();
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery();
               while (rs.next()) {
                Student s = new Student();
                s.setId(rs.getInt("id"));
                s.setName(rs.getString("name"));
                s.setEmail(rs.getString("email"));
                s.setEventname(rs.getString("eventname"));
                list.add(s);
            }
        
        return list;
    }
}
